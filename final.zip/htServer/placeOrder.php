<?php
    session_start();

    // if the user is not signed in, then this page is not accessible
    if (!isset($_SESSION['user_email']) || $_SESSION['user_email'] == '') { 
       
        echo "user is not logged in";
        die();
    }


    $user_email = $_SESSION['user_email'];
    $rest_id = $_POST['restaurant-id'];

    $foods = explode("-", $_POST['food-list']);

    array_shift($foods);

    // establish conection
    include_once("./connection.php");

    $sql = "INSERT INTO `bookings`(`rest_id`, `food_id`, `cust_email`) VALUES ('','','')";

    foreach ($foods as $id) {
        $sql = "INSERT INTO `bookings`(`rest_id`, `food_id`, `cust_email`) VALUES ('$rest_id','$id','$user_email')";

        if (!mysqli_query($conn, $sql)) {
            echo "Error: " . $sql . "<br>" . mysqli_error($conn);
        }
    }

    echo "<html><script> alert('Order placed successfully'); window.location.href = 'http://localhost';</script></html>";
    
    mysqli_close($conn);