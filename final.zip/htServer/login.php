<?php

/**
1. get the form data 
2. validate 
3. establish connnection
4. check if the user given value is found in the database

*/



$email = $_POST['login-email'];
$password = $_POST['login-password'];





//validate email
if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    header("location: http://localhost/login.php?error=Email must be in proper format");
    die();
}

// validate password
if(!empty($password)) {
    if (strlen($password) <= 8) {
        header("location: http://localhost/login.php?error=Your Password Must Contain At Least 8 Characters!"); 
        die();
    }
} else {
    header("location: http://localhost/login.php?error=Your Password Must Contain At Least 8 Character!"); 
        die();
}



// establish connection to database



$servername = "localhost";
$username = "root";
$mysqlpassword = "";
$dbname = "final";

// Create connection
$conn = new mysqli($servername, $username, $mysqlpassword, $dbname);

// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}

$sql = "SELECT * FROM customer WHERE email = '$email' AND password = '$password' ";

$result = $conn->query($sql);

if ($result->num_rows > 0) {

    session_start();

    $_SESSION['user'] = 'active';
    $_SESSION['user_email'] = $email;
  
    header("location: http://localhost/"); 
        die();

} else {
    header("location: http://localhost/login.php?error=Incorrect email or password"); 
        die();
}


$conn->close();